# IBM Data Scientist Professional Certificate capstone project
Determining the best locations in Calgary to open a breakfast restaurant. Visit https://hexaguin.github.io/Coursera_Capstone/ to read the report.
